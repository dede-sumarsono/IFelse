/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ifelse;

/**
 *
 * @author DD
 */
public class IfElse {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int x= 20;
        int y = 18;
        int waktu = 20;
        int time = 22;
        int Time = 20;
        
        if (20>18){
            System.out.println("20 Lebih besar daripada 18");
        }
        
        if (x>y){
            System.out.println("X lebih besar daripada Y");
        }
        
        if (waktu<18){
            System.out.println("Good Day");
        }else{
            System.out.println("Good Evening");
        }
        
        if (time<10){
            System.out.println("Good Morning");
        }else if (time<20){
            System.out.println("Good Day");
        }else{System.out.println("Good Evening");
                }
        
        
        String result = (Time<18)? "Good Day":"Good Evening";
        System.out.println(result);
        
        
    }
    
}
